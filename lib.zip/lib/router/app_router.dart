import 'package:a2zjewelry/features/register/presentation/pages/register_page.dart';
import 'package:go_router/go_router.dart';

class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: '/register',
    routes: [
      GoRoute(
        path: '/register',
        builder: (context, state) => RegisterScreen(),
      ),
      // Add more routes here
    ],
  );
}
