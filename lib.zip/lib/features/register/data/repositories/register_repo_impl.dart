import 'package:a2zjewelry/features/register/data/datasources/remote_register.dart';
import 'package:flutter/material.dart';

class RegisterRepoImpl {
  final Register register;

  RegisterRepoImpl(this.register);

  Future<void> registerUser(Map<String, dynamic> data, BuildContext context) async {
    await register.handleRegister(data, context);
  }
}
