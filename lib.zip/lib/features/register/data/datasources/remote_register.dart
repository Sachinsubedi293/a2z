import 'package:a2zjewelry/core/network/dio_client.dart';
import 'package:a2zjewelry/core/utils/env_components.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class Register {
  final DioClient dioClient;

  Register(this.dioClient);

  Future<void> handleRegister(Map<String, dynamic> data, BuildContext context) async {
    try {
      final response = await dioClient.post('users/register/', data);

      if (response.statusCode == 200) {
        EnvComponents.showSuccessDialog(context, response.data);
      } else {
        EnvComponents.showErrorDialog(context, response.data);
      }
    } catch (e) {
      EnvComponents.showErrorDialog(context, e);
      if (kDebugMode) {
        print('Error during registration: $e');
      }
      rethrow;
    }
  }
}
