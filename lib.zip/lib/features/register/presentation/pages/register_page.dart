import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:a2zjewelry/features/register/presentation/provider/register_state.dart';

class RegisterScreen extends ConsumerStatefulWidget {
  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _allowMail = false;

  @override
  Widget build(BuildContext context) {
    final registrationState = ref.watch(registrationStateProvider);

    return Scaffold(
      appBar: AppBar(title: Text('Register')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(labelText: 'Password'),
            ),
            Row(
              children: [
                Checkbox(
                  value: _allowMail,
                  onChanged: (value) {
                    setState(() {
                      _allowMail = value ?? false;
                    });
                  },
                ),
                Text('Allow Email Notifications'),
              ],
            ),
            SizedBox(height: 16),
            registrationState.when(
              data: (_) => ElevatedButton(
                onPressed: () async {
                  final registrationData = {
                    'email': _emailController.text,
                    'password': _passwordController.text,
                    'allow_mail': _allowMail,
                  };
                  await ref.read(registrationStateProvider.notifier).registerUser(registrationData, context);
                },
                child: Text('Register'),
              ),
              loading: () => CircularProgressIndicator(),
              error: (error, stack) => Text('Error: $error'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
