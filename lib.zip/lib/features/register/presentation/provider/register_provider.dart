import 'package:a2zjewelry/core/network/dio_client.dart';
import 'package:a2zjewelry/features/register/data/datasources/remote_register.dart';
import 'package:a2zjewelry/features/register/data/repositories/register_repo_impl.dart';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// DioClient provider
final dioClientProvider = Provider<DioClient>((ref) {
  final dio = Dio();
  return DioClient(dio: dio);
});

// Register provider
final registerProvider = Provider<Register>((ref) {
  final dioClient = ref.watch(dioClientProvider);
  return Register(dioClient);
});

// RegisterRepo provider
final registerRepoProvider = Provider<RegisterRepoImpl>((ref) {
  final register = ref.watch(registerProvider);
  return RegisterRepoImpl(register);
});
