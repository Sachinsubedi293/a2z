import 'package:a2zjewelry/features/register/data/repositories/register_repo_impl.dart';
import 'package:a2zjewelry/features/register/presentation/provider/register_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// StateNotifier for managing registration state
class RegistrationStateNotifier extends StateNotifier<AsyncValue<void>> {
  final RegisterRepoImpl registerRepo;

  RegistrationStateNotifier(this.registerRepo) : super(const AsyncData(null));

  Future<void> registerUser(Map<String, dynamic> data, BuildContext context) async {
    try {
      state = const AsyncLoading();
      await registerRepo.registerUser(data, context);
      state = const AsyncData(null);
    } catch (e) {
      state = AsyncError(e, StackTrace.current);
    }
  }
}

final registrationStateProvider = StateNotifierProvider<RegistrationStateNotifier, AsyncValue<void>>((ref) {
  final registerRepo = ref.watch(registerRepoProvider);
  return RegistrationStateNotifier(registerRepo);
});
